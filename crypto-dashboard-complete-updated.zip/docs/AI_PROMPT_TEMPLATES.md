# AI PROMPT TEMPLATES DOCUMENTATION
## Hệ Thống Prompt Template Cho Phân Tích Crypto

**Ngày:** 25/12/2024  
**Phiên bản:** 1.0  
**Developer:** Z.AI  
**Ngôn ngữ:** Tiếng Việt

---

## 1. TÓM TẮT HỆ THỐNG PROMPT

### 1.1 Giới Thiệu
Hệ thống AI Prompt Templates được thiết kế để cung cấp phân tích thị trường cryptocurrency chuyên sâu và đa chiều. Các prompt được tối ưu hóa để làm việc với cả Z.AI SDK và ChatGPT, đảm bảo kết quả phân tích nhất quán và đáng tin cậy.

### 1.2 Mục Tiêu Thiết Kế
- **Chuẩn hóa**: Đảm bảo tính nhất quán trong phân tích trên các AI provider
- **Toàn diện**: Bao quát tất cả các khía cạnh của thị trường crypto
- **Linh hoạt**: Hỗ trợ nhiều loại phân tích khác nhau
- **Độ tin cậy**: Cung cấp kết quả có thể validate và kiểm chứng

---

## 2. CẤU TRÚC PROMPT TEMPLATES

### 2.1 Interface Định Nghĩa

```typescript
export interface AIPromptContext {
  coinId: string;
  coinName: string;
  currentPrice: number;
  priceChange24h: number;
  marketCap: number;
  volume24h: number;
  
  // On-chain Metrics
  mvrv: number;
  nupl: number;
  sopr: number;
  activeAddresses: number;
  exchangeInflow: number;
  exchangeOutflow: number;
  transactionVolume: number;
  
  // Technical Indicators
  rsi: number;
  ma50: number;
  ma200: number;
  macd: number;
  bollingerUpper: number;
  bollingerLower: number;
  
  // Sentiment Data
  fearGreedIndex: number;
  fearGreedClassification: string;
  twitterSentiment: number;
  redditSentiment: number;
  socialVolume: number;
  newsSentiment: number;
  newsVolume: number;
  googleTrendsScore: number;
  googleTrendsDirection: string;
  
  // Derivatives Data
  fundingRate: number;
  openInterest: number;
  liquidationVolume: number;
  putCallRatio: number;
  
  // Trading Signal
  tradingSignal: string;
  signalConfidence: number;
  signalRisk: string;
}
```

### 2.2 Kết Quả Phân Tích

```typescript
export interface AIAnalysisResult {
  provider: 'Z.AI' | 'ChatGPT';
  trendAnalysis: string;
  buyRecommendation: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'SELL' | 'STRONG_SELL';
  confidence: number;
  reasoning: string;
  breakoutPotential: 'HIGH' | 'MEDIUM' | 'LOW';
  breakoutReasoning: string;
  keyLevels: {
    support: number[];
    resistance: number[];
  };
  timeHorizon: 'SHORT_TERM' | 'MEDIUM_TERM' | 'LONG_TERM';
  riskFactors: string[];
  opportunities: string[];
  marketRegime: 'BULLISH' | 'BEARISH' | 'RANGING' | 'VOLATILE';
}
```

---

## 3. CÁC LOẠI PROMPT TEMPLATE

### 3.1 Comprehensive Analysis Prompt
**Mục đích**: Phân tích toàn diện thị trường với 47 chỉ báo

**Use Case**: Phân tích đầu tư chi tiết, ra quyết định dài hạn

```typescript
static getComprehensiveAnalysisPrompt(context: AIPromptContext): string {
  return `You are a professional cryptocurrency market analyst with 10+ years of experience...

  [Nội dung prompt đầy đủ với 47 chỉ báo thị trường]
  
  Format your response as a structured JSON object with the following fields:
  {
    "trendAnalysis": "Detailed trend analysis...",
    "buyRecommendation": "STRONG_BUY|BUY|HOLD|SELL|STRONG_SELL",
    "confidence": 0-100,
    "reasoning": "Detailed reasoning...",
    "breakoutPotential": "HIGH|MEDIUM|LOW",
    "breakoutReasoning": "Breakout analysis...",
    "keyLevels": {
      "support": [level1, level2, level3],
      "resistance": [level1, level2, level3]
    },
    "timeHorizon": "SHORT_TERM|MEDIUM_TERM|LONG_TERM",
    "riskFactors": ["risk1", "risk2", "risk3"],
    "opportunities": ["opportunity1", "opportunity2", "opportunity3"],
    "marketRegime": "BULLISH|BEARISH|RANGING|VOLATILE"
  }`;
}
```

**Các Chỉ Bao Gồm**:
- **Market Overview**: Giá, thay đổi 24h, market cap, volume
- **On-chain Analysis**: MVRV, NUPL, SOPR, active addresses
- **Technical Indicators**: RSI, MA50/200, MACD, Bollinger Bands
- **Market Sentiment**: Fear & Greed, social sentiment, news sentiment
- **Derivatives Market**: Funding rate, open interest, liquidations
- **Trading Signals**: Signal hiện tại, confidence, risk level

### 3.2 Quick Analysis Prompt
**Mục đích**: Phân tích nhanh cho trading ngắn hạn

**Use Case**: Quyết định trading nhanh, scalping, swing trading

```typescript
static getQuickAnalysisPrompt(context: AIPromptContext): string {
  return `As a crypto trading expert, provide a quick analysis of ${context.coinName} based on these key metrics:

  Price: $${context.currentPrice.toLocaleString()} (${context.priceChange24h > 0 ? '+' : ''}${context.priceChange24h.toFixed(2)}%)
  RSI: ${context.rsi.toFixed(1)} | MVRV: ${context.mvrv.toFixed(2)} | Fear & Greed: ${context.fearGreedIndex}
  Funding Rate: ${(context.fundingRate * 100).toFixed(3)}% | Signal: ${context.tradingSignal}

  Should investors BUY, HOLD, or SELL right now? Provide brief reasoning and identify any immediate breakout potential.

  Response format: { 
    "recommendation": "BUY|HOLD|SELL", 
    "reasoning": "...", 
    "breakoutPotential": "HIGH|MEDIUM|LOW" 
  }`;
}
```

**Đặc Điểm Nổi Bật**:
- Tập trung vào các chỉ báo quan trọng nhất
- Phản hồi nhanh, phù hợp cho trading thời gian thực
- Định dạng JSON đơn giản, dễ xử lý
- Tối ưu cho các quyết định ngắn hạn

### 3.3 Breakout Analysis Prompt
**Mục đích**: Phát hiện tiềm năng breakout giá

**Use Case**: Xác định điểm vào lệnh, quản lý rủi ro

```typescript
static getBreakoutAnalysisPrompt(context: AIPromptContext): string {
  return `Analyze the breakout potential for ${context.coinName} using these technical and market indicators:

  [Nội dung tập trung vào các chỉ báo breakout]

  Evaluate the probability of a significant price breakout in the next 7-14 days. Consider:
  1. Technical pattern completion
  2. Volume confirmation
  3. Sentiment alignment
  4. Derivatives market pressure
  5. On-chain activity

  Response format: {
    "breakoutPotential": "HIGH|MEDIUM|LOW",
    "breakoutDirection": "UPWARD|DOWNWARD|SIDEWAYS",
    "confidence": 0-100,
    "keyTrigger": "What would trigger the breakout?",
    "priceTarget": "Target price if breakout occurs",
    "timeframe": "Expected timeframe for breakout"
  }`;
}
```

**Các Yếu Tố Breakout**:
- **Technical Setup**: RSI, Moving Averages, MACD, Bollinger Bands
- **Volume & Momentum**: Volume 24h, social volume, Google Trends
- **Market Sentiment**: Fear & Greed, Twitter sentiment, news sentiment
- **Derivatives Pressure**: Funding rate, open interest, put/call ratio

### 3.4 Risk Analysis Prompt
**Mục đích**: Đánh giá rủi ro toàn diện

**Use Case**: Quản lý rủi ro, xác định position size, đặt stop loss

```typescript
static getRiskAnalysisPrompt(context: AIPromptContext): string {
  return `Conduct a comprehensive risk assessment for ${context.coinName} investment:

  [Nội dung tập trung vào các chỉ báo rủi ro]

  Identify and rank the top 5 risk factors for ${context.coinName} investors. For each risk, provide:
  1. Risk level (HIGH/MEDIUM/LOW)
  2. Probability of occurrence (HIGH/MEDIUM/LOW)
  3. Potential impact on price (percentage)
  4. Mitigation strategies

  Response format: {
    "overallRiskLevel": "HIGH|MEDIUM|LOW",
    "riskFactors": [
      {
        "factor": "Risk description",
        "level": "HIGH|MEDIUM|LOW",
        "probability": "HIGH|MEDIUM|LOW",
        "impact": "Estimated percentage impact",
        "mitigation": "How to mitigate this risk"
      }
    ],
    "recommendedPositionSize": "Suggested position size based on risk",
    "stopLossLevel": "Suggested stop loss level"
  }`;
}
```

**Các Chỉ Báo Rủi Ro**:
- **Valuation Risk**: MVRV ratio
- **Profit Realization Risk**: NUPL
- **Technical Risk**: RSI extremes
- **Sentiment Risk**: Fear & Greed extremes
- **Leverage Risk**: Funding rate levels
- **Liquidity Risk**: 24h volume

---

## 4. TÍCH HỢP VÀO HỆ THỐNG

### 4.1 AI Analysis Service Integration

```typescript
export class AIAnalysisService {
  private async executeAIAnalysis(
    provider: 'Z.AI' | 'ChatGPT', 
    context: AIPromptContext, 
    analysisType: 'comprehensive' | 'quick' | 'breakout' | 'risk'
  ): Promise<AIAnalysisResult & { analysisType: string }> {
    let prompt: string;
    
    switch (analysisType) {
      case 'comprehensive':
        prompt = AIPromptTemplates.getComprehensiveAnalysisPrompt(context);
        break;
      case 'quick':
        prompt = AIPromptTemplates.getQuickAnalysisPrompt(context);
        break;
      case 'breakout':
        prompt = AIPromptTemplates.getBreakoutAnalysisPrompt(context);
        break;
      case 'risk':
        prompt = AIPromptTemplates.getRiskAnalysisPrompt(context);
        break;
      default:
        prompt = AIPromptTemplates.getComprehensiveAnalysisPrompt(context);
    }

    const response = await this.callAIProvider(provider, prompt);
    return this.parseAIResponse(response, provider, analysisType);
  }
}
```

### 4.2 Cấu Hình Hệ Thống

```typescript
export interface AIAnalysisConfig {
  providers: ('Z.AI' | 'ChatGPT')[];
  analysisTypes: ('comprehensive' | 'quick' | 'breakout' | 'risk')[];
  timeout: number;
  retryAttempts: number;
}

// Default configuration
const defaultConfig: AIAnalysisConfig = {
  providers: ['Z.AI', 'ChatGPT'],
  analysisTypes: ['comprehensive', 'breakout'],
  timeout: 30000,
  retryAttempts: 3
};
```

### 4.3 Xử Lý Đa Provider

```typescript
private async runProviderAnalysis(context: AIPromptContext): Promise<Record<string, AIAnalysisResult>> {
  const results: Record<string, AIAnalysisResult> = {};
  
  for (const provider of this.config.providers) {
    try {
      console.log(`🤖 Running analysis with ${provider}...`);
      const result = await this.runProviderAnalysisWithType(provider, context);
      results[provider] = result;
    } catch (error) {
      console.error(`❌ Error running analysis with ${provider}:`, error);
      // Continue with other providers even if one fails
    }
  }

  return results;
}
```

---

## 5. CHIẾN LƯỢC SỬ DỤNG PROMPT

### 5.1 Lựa Chọn Prompt Phù Hợp

#### 5.1.1 Theo Mục Đích Phân Tích
- **Đầu tư dài hạn**: Sử dụng Comprehensive Analysis Prompt
- **Trading ngắn hạn**: Sử dụng Quick Analysis Prompt
- **Xác định điểm vào lệnh**: Sử dụng Breakout Analysis Prompt
- **Quản lý rủi ro**: Sử dụng Risk Analysis Prompt

#### 5.1.2 Theo Tình Huống Thị Trường
- **Thị trường biến động mạnh**: Ưu tiên Risk Analysis + Quick Analysis
- **Thị trường trending**: Ưu tiên Breakout Analysis + Comprehensive Analysis
- **Thị trường sideway**: Ưu tiên Quick Analysis + Risk Analysis

### 5.2 Tối Ưu Hóa Prompt

#### 5.2.1 Context Enhancement
```typescript
private enhancePromptContext(baseContext: AIPromptContext): EnhancedAIPromptContext {
  return {
    ...baseContext,
    // Thêm context bổ sung
    marketRegime: this.determineMarketRegime(baseContext),
    volatilityLevel: this.calculateVolatility(baseContext),
    liquidityScore: this.assessLiquidity(baseContext),
    correlationWithBTC: this.calculateBTCCorrelation(baseContext)
  };
}
```

#### 5.2.2 Dynamic Prompt Adjustment
```typescript
private adjustPromptBasedOnConditions(
  basePrompt: string, 
  context: AIPromptContext
): string {
  let adjustedPrompt = basePrompt;
  
  // Thêm cảnh báo rủi ro nếu volatility cao
  if (context.rsi >= 70 || context.rsi <= 30) {
    adjustedPrompt += '\n\nWARNING: Extreme RSI levels detected. Exercise caution.';
  }
  
  // Thêm analysis cho funding rate extremes
  if (Math.abs(context.fundingRate) > 0.01) {
    adjustedPrompt += '\n\nNOTE: Extreme funding rates suggest potential squeeze conditions.';
  }
  
  return adjustedPrompt;
}
```

---

## 6. XỬ LÝ LỖI VÀ FALLBACK

### 6.1 Error Handling Strategy

```typescript
private async executeAIAnalysisWithRetry(
  provider: 'Z.AI' | 'ChatGPT', 
  context: AIPromptContext, 
  analysisType: string
): Promise<AIAnalysisResult> {
  const maxRetries = this.config.retryAttempts;
  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const response = await this.callAIProvider(provider, prompt);
      return this.parseAIResponse(response, provider, analysisType);
    } catch (error) {
      lastError = error as Error;
      console.warn(`⚠️ Attempt ${attempt} failed for ${provider} ${analysisType} analysis:`, error);
      
      if (attempt < maxRetries) {
        // Exponential backoff
        await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, attempt - 1)));
      }
    }
  }

  throw lastError || new Error(`All retry attempts failed for ${provider} ${analysisType} analysis`);
}
```

### 6.2 Fallback Mechanism

```typescript
private async fallbackAnalysis(
  context: AIPromptContext, 
  failedProvider: 'Z.AI' | 'ChatGPT'
): Promise<AIAnalysisResult> {
  // Fallback to remaining provider
  const remainingProvider = failedProvider === 'Z.AI' ? 'ChatGPT' : 'Z.AI';
  
  try {
    return await this.executeAIAnalysis(remainingProvider, context, 'quick');
  } catch (error) {
    // Ultimate fallback to rule-based analysis
    return this.generateRuleBasedAnalysis(context);
  }
}
```

---

## 7. PERFORMANCE VÀ OPTIMIZATION

### 7.1 Caching Strategy

```typescript
class PromptCacheManager {
  private cache = new Map<string, CachedPromptResult>();
  
  async getCachedAnalysis(
    context: AIPromptContext, 
    analysisType: string
  ): Promise<AIAnalysisResult | null> {
    const cacheKey = this.generateCacheKey(context, analysisType);
    const cached = this.cache.get(cacheKey);
    
    if (cached && !this.isExpired(cached.timestamp)) {
      return cached.result;
    }
    
    return null;
  }
  
  private generateCacheKey(context: AIPromptContext, analysisType: string): string {
    return `${context.coinId}_${analysisType}_${Math.floor(context.currentPrice)}`;
  }
}
```

### 7.2 Parallel Processing

```typescript
private async runParallelAnalysis(
  context: AIPromptContext
): Promise<ConsolidatedAIAnalysis> {
  const analysisPromises = this.config.analysisTypes.map(type => 
    this.runAllProvidersForType(context, type)
  );
  
  const results = await Promise.allSettled(analysisPromises);
  
  return this.consolidateParallelResults(results, context);
}
```

---

## 8. TESTING VÀ VALIDATION

### 8.1 Unit Testing

```typescript
describe('AIPromptTemplates', () => {
  const mockContext: AIPromptContext = {
    coinId: 'bitcoin',
    coinName: 'Bitcoin',
    currentPrice: 45000,
    priceChange24h: 2.5,
    // ... other mock data
  };

  test('should generate comprehensive analysis prompt', () => {
    const prompt = AIPromptTemplates.getComprehensiveAnalysisPrompt(mockContext);
    expect(prompt).toContain('Bitcoin');
    expect(prompt).toContain('$45,000');
    expect(prompt).toContain('MVRV');
  });

  test('should generate quick analysis prompt', () => {
    const prompt = AIPromptTemplates.getQuickAnalysisPrompt(mockContext);
    expect(prompt.length).toBeLessThan(1000); // Should be shorter
    expect(prompt).toContain('BUY|HOLD|SELL');
  });
});
```

### 8.2 Integration Testing

```typescript
describe('AI Analysis Integration', () => {
  test('should perform analysis with both providers', async () => {
    const service = AIAnalysisService.getInstance();
    const result = await service.performAnalysis('bitcoin');
    
    expect(result.overallRecommendation).toBeDefined();
    expect(result.overallConfidence).toBeGreaterThan(0);
    expect(result.providers['Z.AI']).toBeDefined();
    expect(result.providers['ChatGPT']).toBeDefined();
  });
});
```

---

## 9. MONITORING VÀ LOGGING

### 9.1 Performance Monitoring

```typescript
class AIPromptMonitor {
  private metrics = new Map<string, PromptMetrics>();
  
  trackPromptUsage(
    provider: 'Z.AI' | 'ChatGPT',
    analysisType: string,
    duration: number,
    success: boolean
  ) {
    const key = `${provider}_${analysisType}`;
    const existing = this.metrics.get(key) || {
      count: 0,
      totalDuration: 0,
      successCount: 0,
      failureCount: 0
    };
    
    this.metrics.set(key, {
      count: existing.count + 1,
      totalDuration: existing.totalDuration + duration,
      successCount: success ? existing.successCount + 1 : existing.successCount,
      failureCount: success ? existing.failureCount : existing.failureCount + 1
    });
  }
  
  getPerformanceReport(): PerformanceReport {
    return {
      totalRequests: Array.from(this.metrics.values()).reduce((sum, m) => sum + m.count, 0),
      averageResponseTime: this.calculateAverageResponseTime(),
      successRate: this.calculateSuccessRate(),
      providerComparison: this.getProviderComparison()
    };
  }
}
```

### 9.2 Quality Assurance

```typescript
class AIResponseValidator {
  validateResponse(response: AIAnalysisResult): ValidationResult {
    const errors: string[] = [];
    
    // Validate confidence score
    if (response.confidence < 0 || response.confidence > 100) {
      errors.push('Confidence score must be between 0 and 100');
    }
    
    // Validate recommendation
    const validRecommendations = ['STRONG_BUY', 'BUY', 'HOLD', 'SELL', 'STRONG_SELL'];
    if (!validRecommendations.includes(response.buyRecommendation)) {
      errors.push('Invalid buy recommendation');
    }
    
    // Validate reasoning length
    if (response.reasoning.length < 50) {
      errors.push('Reasoning too short');
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  }
}
```

---

## 10. KẾT LUẬN VÀ HƯỚNG PHÁT TRIỂN

### 10.1 Thành Tựu Hiện Tại
- ✅ Đã tích hợp thành công 4 loại prompt template chuyên nghiệp
- ✅ Hỗ trợ đa provider (Z.AI và ChatGPT)
- ✅ Xử lý lỗi và fallback mechanism hoàn chỉnh
- ✅ Performance optimization với caching và parallel processing
- ✅ Monitoring và quality assurance system

### 10.2 Hướng Phát Triển Tương Lai
1. **Adaptive Prompts**: Prompts tự động điều chỉnh dựa trên điều kiện thị trường
2. **Machine Learning Integration**: Học hỏi từ hiệu quả prompt để tối ưu hóa
3. **Multi-language Support**: Hỗ trợ thêm ngôn ngữ cho prompt templates
4. **Real-time Prompt Optimization**: Điều chỉnh prompt parameters theo thời gian thực
5. **Advanced Context Awareness**: Context enhancement với dữ liệu thị trường thời gian thực

### 10.3 Best Practices
1. **Luôn validate AI response** trước khi sử dụng
2. **Sử dụng fallback mechanism** để đảm bảo hệ thống luôn hoạt động
3. **Monitor performance metrics** để tối ưu hóa liên tục
4. **Version control prompt templates** để track changes
5. **A/B testing different prompt variations** để cải thiện chất lượng

---

## PHỤ LỤC

### A. Prompt Template Examples
- [Full Comprehensive Analysis Prompt](#31-comprehensive-analysis-prompt)
- [Quick Analysis Prompt Examples](#32-quick-analysis-prompt)
- [Breakout Analysis Sample](#33-breakout-analysis-prompt)
- [Risk Assessment Template](#34-risk-analysis-prompt)

### B. Integration Code Samples
- [AI Analysis Service Integration](#41-ai-analysis-service-integration)
- [Error Handling Examples](#61-error-handling-strategy)
- [Performance Optimization](#71-caching-strategy)

### C. Testing Framework
- [Unit Test Examples](#81-unit-testing)
- [Integration Test Samples](#82-integration-testing)
- [Performance Testing](#91-performance-monitoring)

---

**Document Version**: 1.0  
**Last Updated**: 25/12/2024  
**Next Review**: 01/01/2025