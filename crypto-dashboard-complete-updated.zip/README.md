# 🚀 Crypto Analytics Dashboard

Một hệ thống phân tích thị trường tiền điện tử toàn diện với AI insights và thu thập dữ liệu tự động.

## ✨ Tính Năng Chính

### 📊 Multi-Layer Dashboard
- **On-chain Metrics**: MVRV, NUPL, SOPR, Active Addresses, Exchange Flows
- **Technical Indicators**: RSI, MA50/200, MACD, Bollinger Bands
- **Market Sentiment**: Fear & Greed Index, Social Sentiment, Google Trends
- **Derivatives Data**: Open Interest, Funding Rate, Liquidations, Put/Call Ratio

### 🤖 AI Analysis & Recommendations
- Phân tích thông minh dựa trên nhiều chỉ số
- Đề xuất mua/bán với độ tin cậy
- Giải thích chi tiết lý do đề xuất
- Hỗ trợ đa ngôn ngữ (Tiếng Việt)

### 🪙 Dynamic Coin Management
- **Smart Search**: Tìm kiếm coin từ CoinGecko API với multi-layer fallback
- **Add/Remove Coins**: Thêm/xóa coin động một cách dễ dàng
- **Automated Data Collection**: Tự động thu thập dữ liệu cho coin mới
- **Real-time Status**: Theo dõi trạng thái thu thập dữ liệu real-time
- **Coin Management Panel**: Giao diện quản lý coin chuyên nghiệp
- **Validation & Error Handling**: Validate coin tồn tại và xử lý lỗi robust

### ⚡ Real-time Updates
- WebSocket connection cho cập nhật real-time
- Auto-refresh mỗi 30 giây
- Manual refresh khi cần
- Hiển thị trạng thái kết nối

### 🚨 Alert System
- Tạo cảnh báo tùy chỉnh cho các chỉ số
- Hỗ trợ nhiều loại điều kiện (>, <, >=, <=)
- Theo dõi nhiều metrics cùng lúc
- Thông báo real-time qua WebSocket

## 🛠️ Công Nghệ Sử Dụng

### Frontend
- **Next.js 15** với App Router
- **TypeScript 5** cho type safety
- **Tailwind CSS 4** cho styling
- **shadcn/ui** components
- **Socket.io Client** cho real-time updates
- **Lucide React** icons

### Backend
- **Node.js** với Express
- **Prisma ORM** với SQLite
- **Socket.io** cho real-time communication
- **Z.AI Web SDK** cho AI analysis
- **RESTful API** design

### Data Sources
- **CoinGecko API** cho price data
- **Alternative.me** cho Fear & Greed Index
- **Mock data** cho on-chain metrics (sẽ thay bằng Glassnode/CryptoQuant trong production)
- **AI-powered analysis** với Z.AI

## 🚀 Quick Start

### Yêu cầu
- Node.js 18+
- npm hoặc yarn

### Cài đặt
```bash
# Install dependencies
npm install

# Setup database
npm run db:push

# Start development server
npm run dev
```

### Environment Variables
Tạo file `.env` với các biến:
```env
DATABASE_URL="file:./dev.db"
NEXTAUTH_SECRET="your-secret-key"
NEXTAUTH_URL="http://localhost:3000"
```

## 📱 Hướng Dẫn Sử Dụng

### 1. Dashboard Overview
- **Header**: Chọn coin, trạng thái kết nối, nút refresh/alert
- **Main Metrics**: Price, Volume 24h, Market Cap, Fear & Greed
- **AI Recommendation**: Đề xuất mua/bán với confidence level
- **Detailed Tabs**: 4 tabs cho từng loại metrics

### 2. Tạo Alert
1. Click nút "Alert" ở header
2. Chọn metric muốn theo dõi
3. Chọn operator (>, <, >=, <=)
4. Nhập giá trị ngưỡng
5. Click "Create Alert"

### 3. Real-time Updates
- WebSocket tự động kết nối khi load trang
- Hiển thị trạng thái "Live" khi kết nối thành công
- Data tự động cập nhật mỗi 30 giây
- Có thể manual refresh bằng nút "Refresh"

### 4. Quản Lý Coin (Coin Management)
- **Thêm Coin Mới**: Click "Thêm Coin Mới" button để thêm coin vào hệ thống
- **Tìm Kiếm Coin**: Nhập tên hoặc symbol coin, hệ thống sẽ tìm từ CoinGecko API
- **Quản Lý Coin**: Mở Coin Management Panel để xem tất cả coins
- **Kích Hoạt/Vô Hiệu Hóa**: Toggle active status cho từng coin
- **Thu Thập Dữ Liệu**: Trigger manual data collection khi cần
- **Xóa Coin**: Xóa coin không còn cần thiết (chỉ coin do user thêm)

#### Cách Thêm Coin Mới
1. Click "Thêm Coin Mới" button trên homepage
2. Nhập tên hoặc symbol coin vào ô tìm kiếm (ví dụ: "ena", "ethena")
3. Chọn coin từ kết quả tìm kiếm hiện ra
4. (Optional) Chỉnh sửa symbol hoặc name nếu cần
5. Click "Thêm Coin" button để xác nhận
6. Hệ thống tự động thu thập dữ liệu cho coin mới
7. Coin sẽ xuất hiện trong dropdown selector trên dashboard

#### Coin Management Panel
1. Truy cập `/coin-management` hoặc click "Quản lý Coin" button
2. Xem danh sách tất cả coins với thông tin chi tiết
3. Monitor trạng thái thu thập dữ liệu (PENDING, COLLECTING, COMPLETED, FAILED)
4. Toggle active/inactive status cho từng coin
5. Trigger manual data collection bằng cách click nút thu thập dữ liệu
6. Xóa coin không cần thiết (chỉ áp dụng cho coin do user thêm)

### 5. Phân Tích AI
- AI tự động phân tích khi chọn coin
- Hiển thị signal (BUY/SELL/HOLD/STRONG_BUY/STRONG_SELL)
- Confidence level từ 0-100%
- Reasoning chi tiết bằng Tiếng Việt

## 📊 Các Chỉ Số Theo Dõi

### On-chain Metrics (Ưu tiên cao)
1. **MVRV Ratio** - Market Value to Realized Value
2. **NUPL** - Net Unrealized Profit/Loss
3. **SOPR** - Spent Output Profit Ratio
4. **Active Addresses** - Địa chỉ hoạt động
5. **Exchange Flows** - Dòng tiền lên/rút sàn

### Technical Indicators (Ưu tiên trung bình-cao)
1. **RSI** - Relative Strength Index
2. **MA50/200** - Moving Averages
3. **MACD** - Moving Average Convergence Divergence
4. **Bollinger Bands** - Dải bollinger

### Market Sentiment (Ưu tiên cao)
1. **Fear & Greed Index** (0-100)
2. **Social Sentiment**
3. **Google Trends**

### Derivatives Metrics (Ưu tiên cao)
1. **Funding Rate & Open Interest**
2. **Liquidation Data**
3. **Put/Call Ratio**

## 🔧 API Endpoints

### Core APIs
- `GET /api/health` - Health check
- `GET /api/system-health` - Comprehensive system health
- `GET /api/debug/database` - Database debug information
- `GET /api/crypto` - Crypto data
- `GET /api/cryptocurrencies` - List cryptocurrencies
- `POST /api/cryptocurrencies` - Add new cryptocurrency
- `PUT /api/cryptocurrencies/[id]` - Update cryptocurrency
- `DELETE /api/cryptocurrencies/[id]` - Delete cryptocurrency
- `POST /api/cryptocurrencies/[id]/collect-data` - Trigger data collection

### AI Analysis APIs
- `GET /api/ai-analysis?action=status` - AI analysis service status
- `GET /api/ai-analysis?action=providers` - Available AI providers
- `POST /api/ai-analysis?action=analyze` - Full AI analysis

### Dashboard APIs
- `GET /api/dashboard?coinId=bitcoin` - Dashboard data for specific coin
- `GET /api/dashboard?coinId=ethereum` - Ethereum dashboard data
- `GET /api/dashboard?coinId=binancecoin` - BNB dashboard data

### Trading Signals APIs
- `GET /api/trading-signals-fast?action=signal&coinId=bitcoin` - Fast trading signals
- `GET /api/trading-signals?action=signal&coinId=bitcoin` - Full trading signals

### Feature APIs
- `GET /api/volume` - Volume analysis
- `GET /api/alerts` - Alert management
- `GET /api/alerts-fast?action=process-data&coinId=bitcoin` - Fast alerts
- `POST /api/collector` - Data collection control
- `POST /api/migrate` - Database migration

## 🔍 API Testing and Health Check

### Quick Health Check
```bash
# Check if server is running
curl -s "http://localhost:3000/api/health"

# Check AI analysis status
curl -s "http://localhost:3000/api/ai-analysis?action=status"

# Check dashboard data
curl -s "http://localhost:3000/api/dashboard?coinId=bitcoin"
```

### Comprehensive API Testing
```bash
# Run automated API tests
chmod +x scripts/test-apis.sh
./scripts/test-apis.sh
```

### Manual Testing Examples
```bash
# Test AI analysis with full data
curl -s -X POST "http://localhost:3000/api/ai-analysis?action=analyze" \
  -H "Content-Type: application/json" \
  -d '{
    "coinId": "bitcoin",
    "marketData": {
      "price": {"usd": 65000},
      "onChain": {"mvrv": 1.8},
      "technical": {"rsi": 58.5}
    },
    "tradingSignal": {
      "signal": "BUY",
      "confidence": 75
    },
    "alerts": []
  }'

# Add new cryptocurrency
curl -s -X POST "http://localhost:3000/api/cryptocurrencies" \
  -H "Content-Type: application/json" \
  -d '{
    "coinGeckoId": "solana",
    "symbol": "SOL",
    "name": "Solana",
    "isActive": true
  }'

# Get system health
curl -s "http://localhost:3000/api/system-health"
```

### Expected Results
- **Health Check**: Should return status with 75%+ health percentage
- **AI Analysis**: Should show `initialized: true` and `demoMode: false`
- **Dashboard Data**: Should return real market data with non-zero values
- **Cryptocurrencies**: Should return list with at least Bitcoin
- **Trading Signals**: Should generate BUY/SELL/HOLD recommendations

### Troubleshooting Common Issues
- **Server not running**: Start with `npm run dev`
- **Database connection failed**: Recreate database with `npm run db:push`
- **Cryptocurrency not found**: Add Bitcoin with the POST endpoint above
- **API key issues**: Check `.env` file configuration

### Detailed Documentation
For comprehensive API testing guidance, see:
- [API Testing Guide](./docs/API_TESTING_GUIDE.md) - Complete API testing procedures
- [Health Check Guide](./docs/API_HEALTH_CHECK.md) - Health check documentation
- [macOS Installation Guide](./docs/INSTALLATION_MACOS.md) - macOS setup with testing instructions

## 🎯 Quy Tắc Giao Dịch Đề Xuất

### Tín Hiệu MUA
- MVRV < 1 + Fear & Greed < 20 + Funding âm + SOPR gần 1
- RSI < 30 + Volume tăng + Active addresses tăng
- Extreme Fear zone + Golden Cross vừa xảy ra

### Tín Hiệu BÁN
- MVRV > 2 + Fear & Greed > 80 + Funding dương cao + RSI > 70
- Greed zone + Death Cross + Exchange inflow tăng vọt
- Overbought conditions + Profit taking behavior

### Tín Hiệu GIỮ
- MVRV/NUPL ổn định, volume on-chain tăng
- Không có extreme ở phái sinh/sentiment
- Sideways market với low volatility

## 🔒 Security Considerations

### API Security
- Rate limiting cho external API calls
- Input validation cho tất cả parameters
- Error handling không暴露 thông tin nhạy cảm
- CORS configuration

### Data Security
- Không lưu trữ sensitive data
- Encryption cho user data (nếu có authentication)
- Secure WebSocket connections
- Validation cho tất cả user inputs

### Performance Optimization
- Caching cho API responses
- Debounce cho user actions
- Lazy loading cho components
- Optimized database queries

## 📚 Documentation

### Comprehensive Documentation
Để biết thêm chi tiết về kiến trúc hệ thống và cách triển khai, vui lòng tham khảo tài liệu đầy đủ trong thư mục `docs/`:

#### Installation and Setup
- **[Documentation Index](./docs/README.md)** - Tổng quan tài liệu và hướng dẫn sử dụng
- **[macOS Installation Guide](./docs/INSTALLATION_MACOS.md)** - Hướng dẫn cài đặt chi tiết cho macOS
- **[Installation Documentation Summary](./docs/INSTALLATION_DOCUMENTATION_SUMMARY.md)** - Tổng hợp tài liệu cài đặt
- **[Windows Installation](./docs/INSTALLATION_WINDOWS.md)** - Hướng dẫn cài đặt Windows
- **[Linux Installation](./docs/INSTALLATION_LINUX.md)** - Hướng dẫn cài đặt Linux

#### API Testing and Health Check
- **[API Testing Guide](./docs/API_TESTING_GUIDE.md)** - Hướng dẫn kiểm tra API toàn diện
- **[Health Check Guide](./docs/API_HEALTH_CHECK.md)** - Tài liệu health check và monitoring
- **[Automated Test Script](./scripts/test-apis.sh)** - Script kiểm tra API tự động

#### System Architecture and Design
- **[System Architecture](./docs/SYSTEM_FLOWCHART.md)** - Sơ đồ luồng hệ thống
- **[AI Engine Design](./docs/AI_ENGINE_DESIGN.md)** - Kiến trúc và thiết kế AI engine
- **[Configuration Guide](./docs/CONFIGURATION_GUIDE.md)** - Hướng dẫn cấu hình hệ thống

#### Feature Documentation
- **[Coin Management Feature](./docs/COIN_MANAGEMENT_FEATURE.md)** - Tài liệu chi tiết về tính năng quản lý coin
- **[Crypto Metrics Analysis](./docs/CRYPTO_METRICS_ANALYSIS_REPORT.md)** - Phân tích các chỉ số crypto
- **[Chart Analysis Requirements](./docs/CHART_ANALYSIS_REQUIREMENTS.md)** - Yêu cầu phân tích biểu đồ

#### AI and Analysis
- **[AI Prompt Templates](./docs/AI_PROMPT_TEMPLATES.md)** - Template prompts cho AI analysis
- **[AI Prompt Integration Status](./docs/AI_PROMPT_INTEGRATION_STATUS.md)** - Trạng thái tích hợp AI prompts
- **[Metrics Quality Analysis](./docs/METRICS_QUALITY_ANALYSIS.md)** - Phân tích chất lượng metrics

#### Development and Troubleshooting
- **[Error Resolution](./docs/ERROR_RESOLUTION_REPORT.md)** - Hướng dẫn xử lý lỗi thường gặp
- **[Step-by-Step Development](./docs/STEP_1_YEU_CAU_VA_KE_HOACH.md)** - Yêu cầu và kế hoạch phát triển
- **[Frontend Development](./docs/STEP_3_PHAT_TRIEN_FRONTEND.md)** - Hướng dẫn phát triển frontend

#### API and Setup Documentation
- **[API Setup](./API_SETUP.md)** - Hướng dẫn thiết lập API
- **[AI Setup](./AI_SETUP.md)** - Hướng dẫn thiết lập AI services

### Quick Links
- [🚀 Quick Start](#-quick-start)
- [📱 Hướng Dẫn Sử Dụng](#-hướng-dẫn-sử-dụng)
- [🔧 API Endpoints](#-api-endpoints)
- [🔍 API Testing and Health Check](#-api-testing-and-health-check)
- [📁 Project Structure](#-project-structure)
- [🤝 Contributing](#-contributing)

### Quick Access to Testing
- [Quick Health Check](#-quick-health-check) - Kiểm tra nhanh hệ thống
- [Automated API Testing](#-comprehensive-api-testing) - Chạy test tự động
- [Manual Testing Examples](#-manual-testing-examples) - Test thủ công
- [Troubleshooting Common Issues](#-troubleshooting-common-issues) - Khắc phục sự cố

## 🚀 Production Deployment

### Preparation
1. Replace mock data with real API keys
2. Setup proper database (PostgreSQL recommended)
3. Configure environment variables
4. Setup monitoring and logging
5. Implement proper error handling

### Deployment Steps
```bash
# Build for production
npm run build

# Start production server
npm start
```

### Recommended Services
- **Database**: PostgreSQL hoặc MySQL
- **Caching**: Redis
- **Monitoring**: Datadog hoặc New Relic
- **Logging**: ELK stack hoặc similar
- **CDN**: Cloudflare hoặc AWS CloudFront

## 📁 Project Structure

```
src/
├── app/                    # Next.js App Router pages
│   ├── api/               # API routes
│   │   ├── cryptocurrencies/ # Coin management APIs
│   │   │   ├── route.ts         # CRUD operations
│   │   │   └── [id]/            # Individual coin operations
│   │   ├── crypto/           # Crypto data
│   │   ├── analysis/         # AI analysis
│   │   ├── alerts/           # Alert management
│   │   ├── volume/           # Volume analysis
│   │   └── health/           # Health checks
│   ├── coin-management/     # Coin management page
│   ├── price/             # Price analysis page
│   ├── technical/         # Technical indicators page
│   ├── sentiment/         # Sentiment analysis page
│   ├── volume/            # Volume analysis page
│   └── page.tsx           # Main dashboard
├── components/            # Reusable React components
│   ├── ui/               # shadcn/ui components
│   ├── dashboard/        # Dashboard components
│   ├── CoinManagementPanel.tsx  # Coin management interface
│   ├── AddCoinModal.tsx        # Add coin modal
│   └── PriceVolumeChart.tsx    # Chart components
├── hooks/                 # Custom React hooks
└── lib/                   # Utility functions and services
    ├── data-collector.ts  # Automated data collection
    ├── crypto-service.ts  # Crypto data services
    ├── cryptocurrency-service.ts # Coin management service
    ├── volume-service.ts  # Volume analysis service
    ├── rate-limiter.ts   # API rate limiting
    └── error-handler.ts   # Error handling
```

## 🤝 Contributing

1. Fork repository
2. Create feature branch
3. Make changes with proper testing
4. Submit pull request
5. Code review và merge

## 📄 License

MIT License - see LICENSE file for details

## 🆘 Support

For issues and questions:
- Create GitHub issue
- Check documentation
- Contact development team

---

**Note**: Đây là phiên bản demo với mock data. Trong production, cần tích hợp với real API services như Glassnode, CryptoQuant, CoinMarketCap Pro để có dữ liệu chính xác.

Built with ❤️ for the crypto community. Supercharged by Z.ai 🚀