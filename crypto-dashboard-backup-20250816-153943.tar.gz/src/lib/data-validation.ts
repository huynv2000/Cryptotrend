/**
 * Data Validation and Fallback Service
 * Ensures data authenticity and provides historical fallback mechanisms
 * 
 * This service provides:
 * - Data validation for all incoming metrics
 * - Historical data fallback when external APIs fail
 * - Data quality scoring and monitoring
 * - No mock data - only real data or historical fallback
 * 
 * @author Financial Systems Expert
 * @version 1.0
 */

import { db } from '@/lib/db'

export interface ValidationResult {
  isValid: boolean
  value: any
  confidence: number
  source: 'api' | 'fallback' | 'calculated'
  timestamp: Date
  error?: string
}

export interface DataQualityScore {
  overall: number
  completeness: number
  timeliness: number
  accuracy: number
  consistency: number
}

export class DataValidationService {
  private static instance: DataValidationService
  
  static getInstance(): DataValidationService {
    if (!DataValidationService.instance) {
      DataValidationService.instance = new DataValidationService()
    }
    return DataValidationService.instance
  }

  /**
   * Check if data appears to be mock data
   * Mock data detection patterns:
   * - Perfect round numbers
   * - Repeating patterns
   * - Values that are too clean to be real
   */
  private isMockData(data: any): boolean {
    if (!data || typeof data !== 'object' || data === null) return false
    
    // Check for obvious mock patterns
    for (const [key, value] of Object.entries(data)) {
      if (typeof value === 'number') {
        // Check for perfect round numbers (unlikely in real financial data)
        if (value > 100 && Number.isInteger(value) && value % 1000 === 0) {
          console.warn(`⚠️ Mock pattern detected: ${key} has perfect round number ${value}`)
          return true
        }
        
        // Check for repeating decimals (e.g., 0.333333)
        const decimalStr = value.toString()
        if (decimalStr.includes('.')) {
          const decimalPart = decimalStr.split('.')[1]
          if (decimalPart.length > 3 && /^(\d)\1*$/.test(decimalPart)) {
            console.warn(`⚠️ Mock pattern detected: ${key} has repeating decimals ${value}`)
            return true
          }
        }
      }
    }
    
    return false
  }

  /**
   * Validate price data
   */
  async validatePriceData(cryptoId: string, priceData: any): Promise<ValidationResult> {
    try {
      // Basic validation
      if (!priceData || typeof priceData.usd !== 'number' || priceData.usd <= 0) {
        return {
          isValid: false,
          value: null,
          confidence: 0,
          source: 'rejected',
          timestamp: new Date(),
          error: 'Invalid price data'
        }
      }

      // Validate reasonable price ranges
      const reasonableRanges: Record<string, { min: number; max: number }> = {
        bitcoin: { min: 1000, max: 200000 },
        ethereum: { min: 50, max: 10000 },
        binancecoin: { min: 10, max: 2000 },
        solana: { min: 1, max: 1000 }
      }

      const crypto = await db.cryptocurrency.findFirst({ where: { id: cryptoId } })
      if (!crypto) {
        return {
          isValid: false,
          value: null,
          confidence: 0,
          source: 'rejected',
          timestamp: new Date(),
          error: 'Cryptocurrency not found'
        }
      }

      const range = reasonableRanges[crypto.coinGeckoId] || { min: 0.01, max: 100000 }
      
      if (priceData.usd < range.min || priceData.usd > range.max) {
        console.warn(`⚠️ Price ${priceData.usd} out of reasonable range for ${crypto.symbol}`)
        return {
          isValid: false,
          value: null,
          confidence: 0,
          source: 'rejected',
          timestamp: new Date(),
          error: `Price out of range: ${priceData.usd}`
        }
      }

      return {
        isValid: true,
        value: priceData,
        confidence: 0.95,
        source: 'api',
        timestamp: new Date()
      }
    } catch (error) {
      console.error('❌ Error validating price data:', error)
      return {
        isValid: false,
        value: null,
        confidence: 0,
        source: 'error',
        timestamp: new Date(),
        error: error.message
      }
    }
  }

  /**
   * Validate on-chain metrics - only use real data, no fallback
   */
  async validateOnChainMetrics(cryptoId: string, onChainData: any): Promise<ValidationResult> {
    try {
      // Check if data is null, undefined, or not an object
      if (!onChainData || typeof onChainData !== 'object' || onChainData === null) {
        console.warn('⚠️ No on-chain data provided')
        return {
          isValid: false,
          value: null,
          confidence: 0,
          source: 'rejected',
          timestamp: new Date(),
          error: 'No data provided'
        }
      }

      // Check if data contains mock patterns (random numbers)
      if (this.isMockData(onChainData)) {
        console.warn('⚠️ Detected mock on-chain data, rejecting')
        return {
          isValid: false,
          value: null,
          confidence: 0,
          source: 'rejected',
          timestamp: new Date(),
          error: 'Mock data detected'
        }
      }

      // Validate each metric
      const validationRules = {
        mvrv: { min: 0.1, max: 10, required: true },
        nupl: { min: -1, max: 1, required: true },
        sopr: { min: 0.5, max: 2, required: true },
        activeAddresses: { min: 1000, max: 10000000, required: true },
        newAddresses: { min: 100, max: 5000000, required: false },
        exchangeInflow: { min: 0, max: 1000000000000, required: false }, // Increased to 100B for Bitcoin
        exchangeOutflow: { min: 0, max: 1000000000000, required: false }, // Increased to 100B for Bitcoin
        transactionVolume: { min: 0, max: 1000000000000, required: false } // Increased to 1T for Bitcoin
      }

      for (const [metric, rule] of Object.entries(validationRules)) {
        if (rule.required && (onChainData[metric] === undefined || onChainData[metric] === null)) {
          console.warn(`⚠️ Missing required on-chain metric: ${metric}`)
          return {
            isValid: false,
            value: null,
            confidence: 0,
            source: 'rejected',
            timestamp: new Date(),
            error: `Missing required metric: ${metric}`
          }
        }

        if (onChainData[metric] !== undefined && onChainData[metric] !== null) {
          if (onChainData[metric] < rule.min || onChainData[metric] > rule.max) {
            console.warn(`⚠️ On-chain metric ${metric} value ${onChainData[metric]} out of range`)
            return {
              isValid: false,
              value: null,
              confidence: 0,
              source: 'rejected',
              timestamp: new Date(),
              error: `Metric ${metric} out of range`
            }
          }
        }
      }

      return {
        isValid: true,
        value: onChainData,
        confidence: 0.85,
        source: 'api',
        timestamp: new Date()
      }
    } catch (error) {
      console.error('❌ Error validating on-chain data:', error)
      return {
        isValid: false,
        value: null,
        confidence: 0,
        source: 'error',
        timestamp: new Date(),
        error: error.message
      }
    }
  }

  /**
   * Validate technical indicators - only use real data, no fallback
   */
  async validateTechnicalIndicators(cryptoId: string, technicalData: any): Promise<ValidationResult> {
    try {
      // Check if data is null, undefined, or not an object
      if (!technicalData || typeof technicalData !== 'object' || technicalData === null) {
        console.warn('⚠️ No technical data provided')
        return {
          isValid: false,
          value: null,
          confidence: 0,
          source: 'rejected',
          timestamp: new Date(),
          error: 'No data provided'
        }
      }

      // Check if data contains mock patterns
      if (this.isMockData(technicalData)) {
        console.warn('⚠️ Detected mock technical data, rejecting')
        return {
          isValid: false,
          value: null,
          confidence: 0,
          source: 'rejected',
          timestamp: new Date(),
          error: 'Mock data detected'
        }
      }

      // Validate technical indicators
      const validationRules = {
        rsi: { min: 0, max: 100, required: true },
        ma50: { min: 0, max: 1000000, required: true },
        ma200: { min: 0, max: 1000000, required: true },
        macd: { min: -10000, max: 10000, required: true },
        bollingerUpper: { min: 0, max: 1000000, required: true },
        bollingerLower: { min: 0, max: 1000000, required: true },
        bollingerMiddle: { min: 0, max: 1000000, required: true }
      }

      for (const [metric, rule] of Object.entries(validationRules)) {
        if (rule.required && (technicalData[metric] === undefined || technicalData[metric] === null)) {
          console.warn(`⚠️ Missing required technical metric: ${metric}`)
          return {
            isValid: false,
            value: null,
            confidence: 0,
            source: 'rejected',
            timestamp: new Date(),
            error: `Missing required metric: ${metric}`
          }
        }

        if (technicalData[metric] !== undefined && technicalData[metric] !== null) {
          if (technicalData[metric] < rule.min || technicalData[metric] > rule.max) {
            console.warn(`⚠️ Technical metric ${metric} value ${technicalData[metric]} out of range`)
            return {
              isValid: false,
              value: null,
              confidence: 0,
              source: 'rejected',
              timestamp: new Date(),
              error: `Metric ${metric} out of range`
            }
          }
        }
      }

      return {
        isValid: true,
        value: technicalData,
        confidence: 0.90,
        source: 'api',
        timestamp: new Date()
      }
    } catch (error) {
      console.error('❌ Error validating technical data:', error)
      return {
        isValid: false,
        value: null,
        confidence: 0,
        source: 'error',
        timestamp: new Date(),
        error: error.message
      }
    }
  }

  /**
   * Validate derivative metrics - only use real data, no fallback
   */
  async validateDerivativeMetrics(cryptoId: string, derivativeData: any): Promise<ValidationResult> {
    try {
      // Check if data is null, undefined, or not an object
      if (!derivativeData || typeof derivativeData !== 'object' || derivativeData === null) {
        console.warn('⚠️ No derivative data provided')
        return {
          isValid: false,
          value: null,
          confidence: 0,
          source: 'rejected',
          timestamp: new Date(),
          error: 'No data provided'
        }
      }

      // Check if data contains mock patterns
      if (this.isMockData(derivativeData)) {
        console.warn('⚠️ Detected mock derivative data, rejecting')
        return {
          isValid: false,
          value: null,
          confidence: 0,
          source: 'rejected',
          timestamp: new Date(),
          error: 'Mock data detected'
        }
      }

      // Validate derivative metrics
      const validationRules = {
        openInterest: { min: 0, max: 100000000000, required: true },
        fundingRate: { min: -0.1, max: 0.1, required: true },
        liquidationVolume: { min: 0, max: 1000000000, required: true },
        putCallRatio: { min: 0, max: 10, required: true }
      }

      for (const [metric, rule] of Object.entries(validationRules)) {
        if (rule.required && (derivativeData[metric] === undefined || derivativeData[metric] === null)) {
          console.warn(`⚠️ Missing required derivative metric: ${metric}`)
          return {
            isValid: false,
            value: null,
            confidence: 0,
            source: 'rejected',
            timestamp: new Date(),
            error: `Missing required metric: ${metric}`
          }
        }

        if (derivativeData[metric] !== undefined && derivativeData[metric] !== null) {
          if (derivativeData[metric] < rule.min || derivativeData[metric] > rule.max) {
            console.warn(`⚠️ Derivative metric ${metric} value ${derivativeData[metric]} out of range`)
            return {
              isValid: false,
              value: null,
              confidence: 0,
              source: 'rejected',
              timestamp: new Date(),
              error: `Metric ${metric} out of range`
            }
          }
        }
      }

      return {
        isValid: true,
        value: derivativeData,
        confidence: 0.80,
        source: 'api',
        timestamp: new Date()
      }
    } catch (error) {
      console.error('❌ Error validating derivative data:', error)
      return {
        isValid: false,
        value: null,
        confidence: 0,
        source: 'error',
        timestamp: new Date(),
        error: error.message
      }
    }
  }

}
