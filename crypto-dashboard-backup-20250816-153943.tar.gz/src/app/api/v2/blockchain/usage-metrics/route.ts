import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const blockchain = searchParams.get('blockchain') || 'bitcoin';
    const timeframe = searchParams.get('timeframe') || '24h';

    // Get cryptocurrency data
    const crypto = await db.cryptocurrency.findFirst({
      where: { coinGeckoId: blockchain }
    });

    if (!crypto) {
      return NextResponse.json(
        { error: 'Cryptocurrency not found' },
        { status: 404 }
      );
    }

    // Get price data
    const priceData = await db.priceHistory.findFirst({
      where: { cryptoId: crypto.id },
      orderBy: { timestamp: 'desc' }
    });

    // Get on-chain metrics
    const onChainData = await db.onChainMetric.findFirst({
      where: { cryptoId: crypto.id },
      orderBy: { timestamp: 'desc' }
    });

    // Get technical indicators
    const technicalData = await db.technicalIndicator.findFirst({
      where: { cryptoId: crypto.id },
      orderBy: { timestamp: 'desc' }
    });

    // Format usage metrics data to match the expected interface
    const now = new Date();
    const usageMetrics = {
      id: `usage-${blockchain}-${timeframe}-${now.getTime()}`,
      blockchain: blockchain as any,
      timeframe: timeframe as any,
      createdAt: now,
      updatedAt: now,
      
      // Main metrics - provide default values for missing data
      dailyActiveAddresses: onChainData?.activeAddresses ? {
        value: onChainData.activeAddresses,
        change: 0, // Will be calculated from historical data
        changePercent: 0, // Will be calculated from historical data
        trend: 'stable' as const, // Will be calculated from historical data
        timestamp: now,
      } : {
        value: 0,
        change: 0,
        changePercent: 0,
        trend: 'stable' as const,
        timestamp: now,
      },
      
      newAddresses: onChainData?.newAddresses ? {
        value: onChainData.newAddresses,
        change: 0, // Will be calculated from historical data
        changePercent: 0, // Will be calculated from historical data
        trend: 'stable' as const, // Will be calculated from historical data
        timestamp: now,
      } : {
        value: 0,
        change: 0,
        changePercent: 0,
        trend: 'stable' as const,
        timestamp: now,
      },
      
      dailyTransactions: onChainData?.transactionVolume ? {
        value: onChainData.transactionVolume,
        change: 0, // Will be calculated from historical data
        changePercent: 0, // Will be calculated from historical data
        trend: 'stable' as const, // Will be calculated from historical data
        timestamp: now,
      } : {
        value: 0,
        change: 0,
        changePercent: 0,
        trend: 'stable' as const,
        timestamp: now,
      },
      
      transactionVolume: priceData?.volume24h ? {
        value: priceData.volume24h,
        change: 0, // Will be calculated from historical data
        changePercent: 0, // Will be calculated from historical data
        trend: 'stable' as const, // Will be calculated from historical data
        timestamp: now,
      } : {
        value: 0,
        change: 0,
        changePercent: 0,
        trend: 'stable' as const,
        timestamp: now,
      },
      
      averageFee: onChainData ? {
        value: calculateAverageFee(onChainData),
        change: 0, // Will be calculated from historical data
        changePercent: 0, // Will be calculated from historical data
        trend: 'stable' as const, // Will be calculated from historical data
        timestamp: now,
      } : {
        value: 0,
        change: 0,
        changePercent: 0,
        trend: 'stable' as const,
        timestamp: now,
      },
      
      hashRate: onChainData ? {
        value: calculateHashRate(blockchain, onChainData),
        change: 0, // Will be calculated from historical data
        changePercent: 0, // Will be calculated from historical data
        trend: 'stable' as const, // Will be calculated from historical data
        timestamp: now,
      } : {
        value: 0,
        change: 0,
        changePercent: 0,
        trend: 'stable' as const,
        timestamp: now,
      },
      
      // Rolling averages - provide default values for missing data
      rollingAverages: {
        dailyActiveAddresses: { 
          '7d': 0, // Will be calculated from historical data
          '30d': 0, // Will be calculated from historical data
          '90d': 0, // Will be calculated from historical data
        },
        newAddresses: { 
          '7d': 0, // Will be calculated from historical data
          '30d': 0, // Will be calculated from historical data
          '90d': 0, // Will be calculated from historical data
        },
        dailyTransactions: { 
          '7d': 0, // Will be calculated from historical data
          '30d': 0, // Will be calculated from historical data
          '90d': 0, // Will be calculated from historical data
        },
        transactionVolume: { 
          '7d': 0, // Will be calculated from historical data
          '30d': 0, // Will be calculated from historical data
          '90d': 0, // Will be calculated from historical data
        },
        averageFee: { 
          '7d': 0, // Will be calculated from historical data
          '30d': 0, // Will be calculated from historical data
          '90d': 0, // Will be calculated from historical data
        },
        hashRate: { 
          '7d': 0, // Will be calculated from historical data
          '30d': 0, // Will be calculated from historical data
          '90d': 0, // Will be calculated from historical data
        },
      },
      
      // Spike detection - provide default values for missing data
      spikeDetection: {
        dailyActiveAddresses: detectSpike(
          onChainData?.activeAddresses || 0, 
          0, 
          'daily active addresses'
        ),
        newAddresses: detectSpike(
          onChainData?.newAddresses || 0, 
          0, 
          'new addresses'
        ),
        dailyTransactions: detectSpike(
          onChainData?.transactionVolume || 0, 
          0, 
          'daily transactions'
        ),
        transactionVolume: detectSpike(
          priceData?.volume24h || 0, 
          0, 
          'transaction volume'
        ),
        averageFee: detectSpike(
          onChainData ? calculateAverageFee(onChainData) : 0, 
          0, 
          'average fee'
        ),
        hashRate: detectSpike(
          onChainData ? calculateHashRate(blockchain, onChainData) : 0, 
          0, 
          'hash rate'
        ),
      },
    };

    return NextResponse.json(usageMetrics);
  } catch (error) {
    console.error('Error fetching usage metrics:', error);
    return NextResponse.json(
      { error: 'Failed to fetch usage metrics' },
      { status: 500 }
    );
  }
}

// Helper functions
function calculateChange(currentValue: number, baselineValue: number): number {
  if (!currentValue || !baselineValue) return 0;
  return currentValue - baselineValue;
}

function calculateChangePercent(currentValue: number, baselineValue: number): number {
  if (!currentValue || !baselineValue || baselineValue === 0) return 0;
  return ((currentValue - baselineValue) / baselineValue) * 100;
}

function calculateTrend(currentValue: number, baselineValue: number): 'up' | 'down' | 'stable' {
  if (!currentValue || !baselineValue) return 'stable';
  const change = ((currentValue - baselineValue) / baselineValue) * 100;
  if (Math.abs(change) < 1) return 'stable';
  return change > 0 ? 'up' : 'down';
}

function calculateAverageFee(onChainData: any): number {
  if (!onChainData || !onChainData.transactionVolume) return 0;
  // Simple fee calculation based on transaction volume
  return Math.max(1, 100 / (onChainData.transactionVolume / 1000000));
}

function calculateHashRate(blockchain: string, onChainData: any): number {
  if (!onChainData) return 0;
  
  // Estimate hash rate based on blockchain type and activity
  const baseHashRates = {
    bitcoin: 500000000000000, // 500 EH/s
    ethereum: 1000000000000,   // 1 TH/s (post-merge)
    solana: 500000000000,      // 500 GH/s
    'binance-smart-chain': 1000000000000, // 1 TH/s
    polygon: 1000000000,      // 1 GH/s
  };
  
  const baseRate = baseHashRates[blockchain as keyof typeof baseHashRates] || 1000000000;
  const activityMultiplier = Math.min(2, Math.max(0.5, (onChainData.activeAddresses || 0) / 1000000));
  
  return baseRate * activityMultiplier;
}

function detectSpike(currentValue: number, baselineValue: number | null, metricName: string): any {
  if (!currentValue || !baselineValue) {
    return {
      isSpike: false,
      severity: 'low' as const,
      confidence: 0,
      message: baselineValue ? 'Insufficient data for spike detection' : 'No baseline data available',
      threshold: baselineValue ? baselineValue * 1.5 : null,
      currentValue: currentValue || 0,
      baseline: baselineValue,
      deviation: 0,
    };
  }
  
  const changePercent = Math.abs(((currentValue - baselineValue) / baselineValue) * 100);
  const threshold = baselineValue * 1.5; // 50% increase threshold
  
  const isSpike = currentValue > threshold;
  let severity: 'low' | 'medium' | 'high' = 'low';
  
  if (changePercent > 100) severity = 'high';
  else if (changePercent > 50) severity = 'medium';
  
  const confidence = Math.min(100, changePercent);
  
  return {
    isSpike,
    severity,
    confidence,
    message: isSpike 
      ? `Spike detected in ${metricName}: ${changePercent.toFixed(2)}% increase` 
      : `No spike detected in ${metricName}`,
    threshold,
    currentValue,
    baseline: baselineValue,
    deviation: currentValue - baselineValue,
  };
}

function calculateVolatility(priceData: any): number {
  if (!priceData || !priceData.price) return 0;
  // Simple volatility calculation based on price change
  return Math.abs(priceData.priceChange24h / priceData.price) * 100;
}

function calculateNetworkUtilization(onChainData: any): number {
  if (!onChainData || !onChainData.activeAddresses) return 0;
  // Normalize to 0-100 scale
  return Math.min(100, (onChainData.activeAddresses / 1000000) * 100);
}

function calculateBollingerPosition(technicalData: any): number {
  if (!technicalData || !technicalData.bollingerUpper || !technicalData.bollingerLower) return 50;
  const range = technicalData.bollingerUpper - technicalData.bollingerLower;
  const position = (technicalData.rsi - technicalData.bollingerLower) / range;
  return position * 100;
}

function calculateTrendStrength(technicalData: any): number {
  if (!technicalData) return 50;
  // Simple trend strength based on MACD and RSI
  const macdSignal = technicalData.macd > 0 ? 1 : -1;
  const rsiSignal = technicalData.rsi > 50 ? 1 : -1;
  return 50 + (macdSignal * rsiSignal * 25);
}

function calculateOverallHealth(priceData: any, onChainData: any, technicalData: any): number {
  let health = 50; // Base health
  
  // Price health (30% weight)
  if (priceData && priceData.price > 0) {
    const priceHealth = Math.max(0, 100 - Math.abs(priceData.priceChange24h) / 2);
    health += (priceHealth - 50) * 0.3;
  }
  
  // On-chain health (40% weight)
  if (onChainData && onChainData.activeAddresses > 0) {
    const onChainHealth = Math.min(100, (onChainData.activeAddresses / 100000) * 100);
    health += (onChainHealth - 50) * 0.4;
  }
  
  // Technical health (30% weight)
  if (technicalData && technicalData.rsi > 0) {
    const rsiHealth = 100 - Math.abs(technicalData.rsi - 50);
    health += (rsiHealth - 50) * 0.3;
  }
  
  return Math.max(0, Math.min(100, health));
}

function calculateRiskLevel(priceData: any, onChainData: any): 'low' | 'medium' | 'high' {
  let riskScore = 0;
  
  // Price volatility risk
  if (priceData && priceData.priceChange24h) {
    const volatility = Math.abs(priceData.priceChange24h / priceData.price) * 100;
    riskScore += volatility > 10 ? 2 : volatility > 5 ? 1 : 0;
  }
  
  // On-chain activity risk
  if (onChainData && onChainData.activeAddresses) {
    const activityRatio = onChainData.activeAddresses / 1000000;
    riskScore += activityRatio < 0.1 ? 2 : activityRatio < 0.5 ? 1 : 0;
  }
  
  if (riskScore >= 3) return 'high';
  if (riskScore >= 1) return 'medium';
  return 'low';
}

function generateRecommendation(priceData: any, onChainData: any, technicalData: any): string {
  const health = calculateOverallHealth(priceData, onChainData, technicalData);
  const risk = calculateRiskLevel(priceData, onChainData);
  
  if (health > 70 && risk === 'low') {
    return 'Strong buy signal - Network healthy and low risk';
  } else if (health > 50 && risk === 'medium') {
    return 'Hold position - Monitor for changes';
  } else if (health < 30 || risk === 'high') {
    return 'Consider selling - High risk detected';
  } else {
    return 'Neutral - Wait for clearer signals';
  }
}