// New Addresses Card Component

'use client';

import { UserPlus } from 'lucide-react';
import BaseMetricCard from './BaseMetricCard';
import type { MetricValue, SpikeDetectionResult } from '@/lib/types';

interface NewAddressesCardProps {
  data: MetricValue | null;
  spikeDetection?: SpikeDetectionResult;
  isLoading: boolean;
  isSelected?: boolean;
  onClick?: () => void;
}

export default function NewAddressesCard({
  data,
  spikeDetection,
  isLoading,
  isSelected = false,
  onClick
}: NewAddressesCardProps) {
  // Only use real data - no mock data
  const sparklineData = data && data.historicalData ? data.historicalData : null;
  
  return (
    <BaseMetricCard
      title="New Addresses"
      description="Newly created addresses"
      data={data}
      spikeDetection={spikeDetection}
      isLoading={isLoading}
      isSelected={isSelected}
      onClick={onClick}
      icon={<UserPlus className="h-5 w-5 text-green-500" />}
      formatType="number"
      isPositiveGood={true}
      showSparkline={!!sparklineData}
      sparklineData={sparklineData}
      className="hover:border-green-500/30"
    />
  );
}