// Daily Active Addresses Card Component

'use client';

import { Users } from 'lucide-react';
import BaseMetricCard from './BaseMetricCard';
import type { MetricValue, SpikeDetectionResult } from '@/lib/types';

interface DailyActiveAddressesCardProps {
  data: MetricValue | null;
  spikeDetection?: SpikeDetectionResult;
  isLoading: boolean;
  isSelected?: boolean;
  onClick?: () => void;
}

export default function DailyActiveAddressesCard({
  data,
  spikeDetection,
  isLoading,
  isSelected = false,
  onClick
}: DailyActiveAddressesCardProps) {
  // Only use real data - no mock data
  const sparklineData = data && data.historicalData ? data.historicalData : null;
  
  return (
    <BaseMetricCard
      title="Daily Active Addresses"
      description="Number of unique active addresses"
      data={data}
      spikeDetection={spikeDetection}
      isLoading={isLoading}
      isSelected={isSelected}
      onClick={onClick}
      icon={<Users className="h-5 w-5 text-blue-500" />}
      formatType="number"
      isPositiveGood={true}
      showSparkline={!!sparklineData}
      sparklineData={sparklineData}
      className="hover:border-blue-500/30"
    />
  );
}