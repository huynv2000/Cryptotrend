// Transaction Volume Card Component

'use client';

import { DollarSign } from 'lucide-react';
import BaseMetricCard from './BaseMetricCard';
import type { MetricValue, SpikeDetectionResult } from '@/lib/types';

interface TransactionVolumeCardProps {
  data: MetricValue | null;
  spikeDetection?: SpikeDetectionResult;
  isLoading: boolean;
  isSelected?: boolean;
  onClick?: () => void;
}

export default function TransactionVolumeCard({
  data,
  spikeDetection,
  isLoading,
  isSelected = false,
  onClick
}: TransactionVolumeCardProps) {
  // Only use real data - no mock data
  const sparklineData = data && data.historicalData ? data.historicalData : null;
  
  return (
    <BaseMetricCard
      title="Transaction Volume"
      description="Total transaction volume in USD"
      data={data}
      spikeDetection={spikeDetection}
      isLoading={isLoading}
      isSelected={isSelected}
      onClick={onClick}
      icon={<DollarSign className="h-5 w-5 text-orange-500" />}
      formatType="currency"
      isPositiveGood={true}
      showSparkline={!!sparklineData}
      sparklineData={sparklineData}
      className="hover:border-orange-500/30"
    />
  );
}