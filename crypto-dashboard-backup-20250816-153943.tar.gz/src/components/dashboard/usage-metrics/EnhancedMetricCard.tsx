// Enhanced Metric Card Component with Absolute Values and Baseline Comparison

'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { TrendingUp, TrendingDown, Minus, AlertTriangle, Info, CheckCircle, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatNumber, formatPercent, formatCurrency, formatHashRate, getTrendColor } from '@/lib/utils';
import type { EnhancedMetricValue } from '@/lib/enhanced-data-provider';

interface EnhancedMetricCardProps {
  title: string;
  description?: string;
  data: EnhancedMetricValue | null;
  spikeDetection?: {
    isSpike: boolean;
    severity: 'low' | 'medium' | 'high';
    confidence: number;
    message: string;
  };
  isLoading: boolean;
  isSelected?: boolean;
  onClick?: () => void;
  icon?: React.ReactNode;
  formatType?: 'number' | 'currency' | 'percent' | 'hashrate';
  unit?: string;
  isPositiveGood?: boolean;
  showSparkline?: boolean;
  sparklineData?: number[];
  showAbsoluteValue?: boolean;
  showBaseline?: boolean;
  showConfidence?: boolean;
  showSource?: boolean;
  className?: string;
}

export default function EnhancedMetricCard({
  title,
  description,
  data,
  spikeDetection,
  isLoading,
  isSelected = false,
  onClick,
  icon,
  formatType = 'number',
  unit,
  isPositiveGood = true,
  showSparkline = false,
  sparklineData = [],
  showAbsoluteValue = true,
  showBaseline = true,
  showConfidence = true,
  showSource = true,
  className
}: EnhancedMetricCardProps) {
  const formatValue = (value: number) => {
    switch (formatType) {
      case 'currency':
        return formatCurrency(value);
      case 'percent':
        return formatPercent(value);
      case 'hashrate':
        return formatHashRate(value);
      default:
        return formatNumber(value);
    }
  };
  
  const getTrendIcon = () => {
    if (!data) return <Minus className="h-4 w-4" />;
    
    if (data.change > 0) return <TrendingUp className="h-4 w-4" />;
    if (data.change < 0) return <TrendingDown className="h-4 w-4" />;
    return <Minus className="h-4 w-4" />;
  };
  
  const getChangeColor = () => {
    if (!data) return 'text-gray-500';
    return getTrendColor(data.change, isPositiveGood);
  };
  
  const getSpikeBadge = () => {
    if (!spikeDetection || !spikeDetection.isSpike) return null;
    
    const variant = spikeDetection.severity === 'high' ? 'destructive' : 
                   spikeDetection.severity === 'medium' ? 'default' : 'secondary';
    
    return (
      <Badge variant={variant} className="text-xs">
        <AlertTriangle className="h-3 w-3 mr-1" />
        Spike
      </Badge>
    );
  };

  const getSourceBadge = () => {
    if (!data || !showSource) return null;
    
    const variant = data.source === 'real' ? 'default' : 
                   data.source === 'estimated' ? 'secondary' : 'outline';
    
    const icon = data.source === 'real' ? <CheckCircle className="h-3 w-3 mr-1" /> :
                 data.source === 'estimated' ? <AlertCircle className="h-3 w-3 mr-1" /> :
                 <Info className="h-3 w-3 mr-1" />;
    
    return (
      <Badge variant={variant} className="text-xs">
        {icon}
        {data.source}
      </Badge>
    );
  };

  const getConfidenceIndicator = () => {
    if (!data || !showConfidence) return null;
    
    const confidencePercent = data.confidence * 100;
    let color = 'text-green-600';
    if (confidencePercent < 70) color = 'text-red-600';
    else if (confidencePercent < 90) color = 'text-yellow-600';
    
    return (
      <div className={`text-xs ${color}`}>
        Confidence: {confidencePercent.toFixed(0)}%
      </div>
    );
  };
  
  const renderSparkline = () => {
    if (!showSparkline || sparklineData.length === 0) return null;
    
    const min = Math.min(...sparklineData);
    const max = Math.max(...sparklineData);
    const range = max - min || 1;
    
    return (
      <div className="mt-2 h-12 relative">
        <svg
          width="100%"
          height="100%"
          viewBox={`0 0 ${sparklineData.length} 100`}
          preserveAspectRatio="none"
          className="overflow-visible"
        >
          {/* Gradient fill */}
          <defs>
            <linearGradient id={`gradient-${title}`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="currentColor" stopOpacity="0.2" />
              <stop offset="100%" stopColor="currentColor" stopOpacity="0.05" />
            </linearGradient>
          </defs>
          
          {/* Area fill */}
          <path
            d={`M 0,100 ${sparklineData.map((value, index) => 
              `L ${index},${100 - ((value - min) / range) * 100}`
            ).join(' ')} L ${sparklineData.length - 1},100 Z`}
            fill={`url(#gradient-${title})`}
            className="text-blue-500"
          />
          
          {/* Line */}
          <path
            d={`M ${sparklineData.map((value, index) => 
              `${index},${100 - ((value - min) / range) * 100}`
            ).join(' ')}`}
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            className="text-blue-500"
          />
          
          {/* Data points */}
          {sparklineData.map((value, index) => (
            <circle
              key={index}
              cx={index}
              cy={100 - ((value - min) / range) * 100}
              r="2"
              fill="currentColor"
              className="text-blue-500"
            />
          ))}
        </svg>
      </div>
    );
  };

  const renderBaselineComparison = () => {
    if (!data || !showBaseline) return null;
    
    const { baselineValues } = data;
    
    return (
      <div className="space-y-1">
        <div className="text-xs text-muted-foreground font-medium">Baseline Comparison:</div>
        <div className="grid grid-cols-3 gap-2 text-xs">
          <div className="text-center">
            <div className="text-muted-foreground">vs 7D</div>
            <div className={cn(
              "font-medium",
              data.value > baselineValues['7d'] ? "text-green-600" : 
              data.value < baselineValues['7d'] ? "text-red-600" : "text-gray-600"
            )}>
              {formatValue(baselineValues['7d'])}
            </div>
            <div className={cn(
              "text-xs",
              data.value > baselineValues['7d'] ? "text-green-600" : 
              data.value < baselineValues['7d'] ? "text-red-600" : "text-gray-500"
            )}>
              {data.value > baselineValues['7d'] ? '+' : ''}{((data.value - baselineValues['7d']) / baselineValues['7d'] * 100).toFixed(1)}%
            </div>
          </div>
          <div className="text-center">
            <div className="text-muted-foreground">vs 30D</div>
            <div className={cn(
              "font-medium",
              data.value > baselineValues['30d'] ? "text-green-600" : 
              data.value < baselineValues['30d'] ? "text-red-600" : "text-gray-600"
            )}>
              {formatValue(baselineValues['30d'])}
            </div>
            <div className={cn(
              "text-xs",
              data.value > baselineValues['30d'] ? "text-green-600" : 
              data.value < baselineValues['30d'] ? "text-red-600" : "text-gray-500"
            )}>
              {data.value > baselineValues['30d'] ? '+' : ''}{((data.value - baselineValues['30d']) / baselineValues['30d'] * 100).toFixed(1)}%
            </div>
          </div>
          <div className="text-center">
            <div className="text-muted-foreground">vs 90D</div>
            <div className={cn(
              "font-medium",
              data.value > baselineValues['90d'] ? "text-green-600" : 
              data.value < baselineValues['90d'] ? "text-red-600" : "text-gray-600"
            )}>
              {formatValue(baselineValues['90d'])}
            </div>
            <div className={cn(
              "text-xs",
              data.value > baselineValues['90d'] ? "text-green-600" : 
              data.value < baselineValues['90d'] ? "text-red-600" : "text-gray-500"
            )}>
              {data.value > baselineValues['90d'] ? '+' : ''}{((data.value - baselineValues['90d']) / baselineValues['90d'] * 100).toFixed(1)}%
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  if (isLoading) {
    return (
      <Card className={cn(
        "animate-pulse cursor-pointer hover:shadow-md transition-shadow",
        isSelected && "ring-2 ring-blue-500",
        className
      )}>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="h-5 w-5 bg-muted rounded"></div>
              <div className="h-4 bg-muted rounded w-24"></div>
            </div>
            <div className="h-6 bg-muted rounded w-16"></div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="h-8 bg-muted rounded w-32"></div>
            <div className="h-4 bg-muted rounded w-full"></div>
            <div className="h-12 bg-muted rounded w-full"></div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (!data) {
    return (
      <Card className={cn(
        "cursor-pointer hover:shadow-md transition-shadow",
        isSelected && "ring-2 ring-blue-500",
        className
      )}>
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <Info className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">No data available</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card 
      className={cn(
        "cursor-pointer hover:shadow-md transition-all duration-200",
        isSelected && "ring-2 ring-blue-500 bg-blue-500/5",
        spikeDetection?.isSpike && "border-orange-500/50",
        className
      )}
      onClick={onClick}
    >
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {icon}
            <div>
              <CardTitle className="text-sm font-medium">
                {title}
              </CardTitle>
              {description && (
                <p className="text-xs text-muted-foreground mt-1">
                  {description}
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {getSpikeBadge()}
            {getSourceBadge()}
            <div className={cn("flex items-center space-x-1", getChangeColor())}>
              {getTrendIcon()}
              <span className="text-xs font-medium">
                {data.change >= 0 ? '+' : ''}{data.changePercent.toFixed(2)}%
              </span>
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-3">
          {/* Main Value Display */}
          <div className="flex items-baseline space-x-2">
            {showAbsoluteValue && (
              <div className="text-2xl font-bold">
                {data.formattedValue}
              </div>
            )}
            {unit && (
              <span className="text-sm text-muted-foreground">
                {unit}
              </span>
            )}
          </div>
          
          {/* Additional Info */}
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Abs: {formatValue(data.absoluteValue)}</span>
            <span>Change: {data.change >= 0 ? '+' : ''}{formatValue(data.change)}</span>
            <span>Trend: {data.trend}</span>
          </div>
          
          {/* Confidence Indicator */}
          {getConfidenceIndicator()}
          
          {/* Baseline Comparison */}
          {renderBaselineComparison()}
          
          {/* Sparkline */}
          {renderSparkline()}
          
          {/* Status Indicators */}
          <div className="flex items-center justify-between pt-2 border-t border-border">
            <div className="flex items-center space-x-2">
              <div className={cn(
                "w-2 h-2 rounded-full",
                data.trend === 'up' ? 'bg-green-500' :
                data.trend === 'down' ? 'bg-red-500' : 'bg-gray-500'
              )} />
              <span className="text-xs capitalize">{data.trend}</span>
            </div>
            
            {spikeDetection?.isSpike && (
              <div className="flex items-center space-x-1">
                <AlertTriangle className="h-3 w-3 text-orange-500" />
                <span className="text-xs text-orange-500">
                  {spikeDetection.severity} spike
                </span>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}