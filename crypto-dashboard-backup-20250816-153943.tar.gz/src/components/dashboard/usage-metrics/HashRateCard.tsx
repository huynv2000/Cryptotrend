// Hash Rate Card Component

'use client';

import { Hash } from 'lucide-react';
import BaseMetricCard from './BaseMetricCard';
import type { MetricValue, SpikeDetectionResult } from '@/lib/types';

interface HashRateCardProps {
  data: MetricValue | null;
  spikeDetection?: SpikeDetectionResult;
  isLoading: boolean;
  isSelected?: boolean;
  onClick?: () => void;
}

export default function HashRateCard({
  data,
  spikeDetection,
  isLoading,
  isSelected = false,
  onClick
}: HashRateCardProps) {
  // Only use real data - no mock data
  const sparklineData = data && data.historicalData ? data.historicalData : null;
  
  return (
    <BaseMetricCard
      title="Network Hash Rate"
      description="Current network hash rate"
      data={data}
      spikeDetection={spikeDetection}
      isLoading={isLoading}
      isSelected={isSelected}
      onClick={onClick}
      icon={<Hash className="h-5 w-5 text-yellow-500" />}
      formatType="hashrate"
      isPositiveGood={true}
      showSparkline={!!sparklineData}
      sparklineData={sparklineData}
      className="hover:border-yellow-500/30"
    />
  );
}