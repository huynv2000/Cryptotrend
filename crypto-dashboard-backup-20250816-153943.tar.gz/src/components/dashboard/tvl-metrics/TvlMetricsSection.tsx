// TVL Metrics Section Component

'use client';

import { useState } from 'react';
import { TrendingUp, TrendingDown, BarChart3, PieChart, Layers, Target, DollarSign, Award, Activity } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LoadingState } from '@/components/LoadingState';
import { cn, formatNumber, formatCurrency } from '@/lib/utils';
import type { TVLMetrics, BlockchainValue, TimeframeValue } from '@/lib/types';

interface TvlMetricsSectionProps {
  blockchain: BlockchainValue;
  timeframe: TimeframeValue;
  data: TVLMetrics | null;
  isLoading: boolean;
}

const tvlMetricsConfig = [
  {
    key: 'chainTVL',
    title: 'Chain TVL',
    icon: DollarSign,
    description: 'Total Value Locked',
    color: 'text-green-500',
    format: 'currency'
  },
  {
    key: 'tvlDominance',
    title: 'TVL Dominance',
    icon: Award,
    description: 'Market share percentage',
    color: 'text-blue-500',
    format: 'percentage'
  },
  {
    key: 'tvlRank',
    title: 'TVL Rank',
    icon: Target,
    description: 'Global ranking',
    color: 'text-purple-500',
    format: 'number'
  },
  {
    key: 'tvlToMarketCapRatio',
    title: 'TVL/MC Ratio',
    icon: BarChart3,
    description: 'TVL to Market Cap ratio',
    color: 'text-orange-500',
    format: 'percentage'
  },
  {
    key: 'defiTVL',
    title: 'DeFi TVL',
    icon: Layers,
    description: 'DeFi protocols TVL',
    color: 'text-cyan-500',
    format: 'currency'
  },
  {
    key: 'stakingTVL',
    title: 'Staking TVL',
    icon: Activity,
    description: 'Staking protocols TVL',
    color: 'text-emerald-500',
    format: 'currency'
  }
];

export default function TvlMetricsSection({
  blockchain,
  timeframe,
  data,
  isLoading
}: TvlMetricsSectionProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedMetric, setSelectedMetric] = useState<string | null>(null);
  const [selectedTab, setSelectedTab] = useState('overview');
  
  const handleMetricClick = (metricKey: string) => {
    setSelectedMetric(selectedMetric === metricKey ? null : metricKey);
  };
  
  if (isLoading && !data) {
    return (
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold">TVL Metrics</h2>
            <p className="text-sm text-muted-foreground">
              Total Value Locked analysis for {blockchain}
            </p>
          </div>
          <LoadingState text="Loading TVL metrics..." />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-2">
                <div className="h-4 bg-muted rounded w-3/4"></div>
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-muted rounded w-1/2 mb-2"></div>
                <div className="h-4 bg-muted rounded w-full"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    );
  }
  
  if (!data) {
    return (
      <section className="space-y-4">
        <div>
          <h2 className="text-xl font-semibold">TVL Metrics</h2>
          <p className="text-sm text-muted-foreground">
            Total Value Locked analysis for {blockchain}
          </p>
        </div>
        <Card>
          <CardContent className="flex items-center justify-center py-8">
            <div className="text-center">
              <div className="text-red-500 mb-2">No TVL data available</div>
              <p className="text-muted-foreground">
                Unable to load TVL metrics for {blockchain}
              </p>
            </div>
          </CardContent>
        </Card>
      </section>
    );
  }
  
  return (
    <section className="space-y-4">
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">TVL Metrics</h2>
          <p className="text-sm text-muted-foreground">
            Total Value Locked analysis for {blockchain} • {timeframe}
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant={viewMode === 'grid' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('grid')}
          >
            Grid
          </Button>
          <Button
            variant={viewMode === 'list' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('list')}
          >
            List
          </Button>
        </div>
      </div>
      
      {/* Summary Stats */}
      <Card className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border-green-500/20">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {tvlMetricsConfig.map((metric) => {
              const metricData = data[metric.key as keyof TVLMetrics] as any;
              const value = metricData?.value || 0;
              const changePercent = metricData?.changePercent || 0;
              const isPositive = changePercent >= 0;
              
              let displayValue = formatNumber(value);
              if (metric.format === 'currency') {
                displayValue = formatCurrency(value);
              } else if (metric.format === 'percentage') {
                displayValue = `${value.toFixed(2)}%`;
              }
              
              return (
                <div key={metric.key} className="text-center">
                  <metric.icon className={cn(
                    "h-4 w-4 mx-auto mb-1",
                    metric.color
                  )} />
                  <div className="text-xs text-muted-foreground">
                    {metric.title}
                  </div>
                  <div className="text-sm font-medium">
                    {displayValue}
                  </div>
                  <div className={cn(
                    "text-xs",
                    isPositive ? "text-green-500" : "text-red-500"
                  )}>
                    {isPositive ? '+' : ''}{changePercent.toFixed(1)}%
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
      
      {/* Main Content */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="composition">Composition</TabsTrigger>
          <TabsTrigger value="protocols">Protocols</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-4">
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {tvlMetricsConfig.map((metric) => {
                const metricData = data[metric.key as keyof TVLMetrics] as any;
                const value = metricData?.value || 0;
                const changePercent = metricData?.changePercent || 0;
                const isPositive = changePercent >= 0;
                
                let displayValue = formatNumber(value);
                if (metric.format === 'currency') {
                  displayValue = formatCurrency(value);
                } else if (metric.format === 'percentage') {
                  displayValue = `${value.toFixed(2)}%`;
                }
                
                return (
                  <Card 
                    key={metric.key}
                    className={cn(
                      "cursor-pointer transition-all hover:shadow-md",
                      selectedMetric === metric.key && "ring-2 ring-primary"
                    )}
                    onClick={() => handleMetricClick(metric.key)}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <metric.icon className={cn("h-5 w-5", metric.color)} />
                        <Badge 
                          variant={isPositive ? "default" : "destructive"}
                          className="text-xs"
                        >
                          {isPositive ? (
                            <TrendingUp className="h-3 w-3 mr-1" />
                          ) : (
                            <TrendingDown className="h-3 w-3 mr-1" />
                          )}
                          {isPositive ? '+' : ''}{changePercent.toFixed(1)}%
                        </Badge>
                      </div>
                      <CardTitle className="text-sm font-medium">
                        {metric.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold mb-1">
                        {displayValue}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {metric.description}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card>
              <CardContent className="p-0">
                <div className="space-y-0">
                  {tvlMetricsConfig.map((metric) => {
                    const metricData = data[metric.key as keyof TVLMetrics] as any;
                    const value = metricData?.value || 0;
                    const changePercent = metricData?.changePercent || 0;
                    const isPositive = changePercent >= 0;
                    
                    let displayValue = formatNumber(value);
                    if (metric.format === 'currency') {
                      displayValue = formatCurrency(value);
                    } else if (metric.format === 'percentage') {
                      displayValue = `${value.toFixed(2)}%`;
                    }
                    
                    return (
                      <div
                        key={metric.key}
                        className={cn(
                          "flex items-center justify-between p-4 border-b border-border last:border-b-0",
                          selectedMetric === metric.key && "bg-accent"
                        )}
                        onClick={() => handleMetricClick(metric.key)}
                      >
                        <div className="flex items-center space-x-3">
                          <metric.icon className={cn(
                            "h-5 w-5",
                            metric.color
                          )} />
                          <div>
                            <div className="font-medium">{metric.title}</div>
                            <div className="text-sm text-muted-foreground">
                              {metric.description}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">
                            {displayValue}
                          </div>
                          <div className={cn(
                            "text-sm",
                            isPositive ? "text-green-500" : "text-red-500"
                          )}>
                            {isPositive ? '+' : ''}{changePercent.toFixed(1)}%
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="composition" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <PieChart className="h-5 w-5 text-blue-500" />
                  <span>TVL Composition</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { key: 'defiTVL', label: 'DeFi Protocols', color: 'bg-blue-500' },
                    { key: 'stakingTVL', label: 'Staking', color: 'bg-green-500' },
                    { key: 'bridgeTVL', label: 'Bridges', color: 'bg-purple-500' },
                    { key: 'lendingTVL', label: 'Lending', color: 'bg-orange-500' },
                    { key: 'dexTVL', label: 'DEX', color: 'bg-cyan-500' },
                    { key: 'yieldTVL', label: 'Yield Farming', color: 'bg-emerald-500' }
                  ].map((item) => {
                    const metricData = data[item.key as keyof TVLMetrics] as any;
                    const value = metricData?.value || 0;
                    const totalTVL = data.chainTVL?.value || 1;
                    const percentage = totalTVL > 0 ? (value / totalTVL) * 100 : 0;
                    
                    return (
                      <div key={item.key} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <div className={cn("w-3 h-3 rounded-full", item.color)} />
                          <span className="text-sm">{item.label}</span>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">{formatCurrency(value)}</div>
                          <div className="text-xs text-muted-foreground">
                            {percentage.toFixed(1)}%
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5 text-green-500" />
                  <span>TVL Changes</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { key: 'chainTVLChange24h', label: '24h Change', period: '24h' },
                    { key: 'chainTVLChange7d', label: '7d Change', period: '7d' },
                    { key: 'chainTVLChange30d', label: '30d Change', period: '30d' }
                  ].map((item) => {
                    const metricData = data[item.key as keyof TVLMetrics] as any;
                    const value = metricData?.value || 0;
                    const isPositive = value >= 0;
                    
                    return (
                      <div key={item.key} className="flex items-center justify-between">
                        <span className="text-sm">{item.label}</span>
                        <div className={cn(
                          "font-semibold",
                          isPositive ? "text-green-500" : "text-red-500"
                        )}>
                          {isPositive ? '+' : ''}{value.toFixed(2)}%
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="protocols" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Layers className="h-5 w-5 text-purple-500" />
                <span>Top Protocols by TVL</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {data.topProtocolsByTVL && data.topProtocolsByTVL.length > 0 ? (
                <div className="space-y-2">
                  {data.topProtocolsByTVL.slice(0, 10).map((protocol, index) => (
                    <div key={protocol.name} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="text-sm font-medium text-muted-foreground">
                          #{index + 1}
                        </div>
                        <div>
                          <div className="font-medium">{protocol.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {protocol.category}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">{formatCurrency(protocol.tvl)}</div>
                        <div className={cn(
                          "text-xs",
                          protocol.change24h >= 0 ? "text-green-500" : "text-red-500"
                        )}>
                          {protocol.change24h >= 0 ? '+' : ''}{protocol.change24h.toFixed(2)}%
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Layers className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">
                    No protocol data available
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="h-5 w-5 text-orange-500" />
                  <span>TVL Analytics</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Current TVL</span>
                    <span className="font-semibold">{formatCurrency(data.chainTVL?.value || 0)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Peak TVL</span>
                    <span className="font-semibold">{formatCurrency(data.tvlPeak?.value || 0)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Global Rank</span>
                    <span className="font-semibold">#{data.tvlRank?.value || 'N/A'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Market Dominance</span>
                    <span className="font-semibold">{(data.tvlDominance?.value || 0).toFixed(2)}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-cyan-500" />
                  <span>Market Context</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">TVL/MC Ratio</span>
                    <span className="font-semibold">{(data.tvlToMarketCapRatio?.value || 0).toFixed(2)}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Protocol Count</span>
                    <span className="font-semibold">{data.topProtocolsByTVL?.length || 0}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Categories</span>
                    <span className="font-semibold">{data.protocolCategories?.length || 0}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Data Confidence</span>
                    <Badge variant="outline" className="text-xs">
                      High
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Selected Metric Detail */}
      {selectedMetric && (
        <Card className="border-green-500/20">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Detailed View: {tvlMetricsConfig.find(m => m.key === selectedMetric)?.title}</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedMetric(null)}
              >
                Close
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">
                Detailed TVL analysis will be displayed here
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </section>
  );
}