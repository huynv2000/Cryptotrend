'use client';

import BlockchainDashboard from '@/components/dashboard/BlockchainDashboard';

export default function Home() {
  return <BlockchainDashboard />;
}