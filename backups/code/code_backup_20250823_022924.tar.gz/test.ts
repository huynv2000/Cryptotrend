
const test: string = "Hello TypeScript";
console.log(test);
